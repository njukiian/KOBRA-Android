# KOBRA Android app — starter project

This is a native Android (Kotlin) starter project, not a website. It contains:
- Native Android screens: Home, Markets, Safety, News and Alerts
- A local notification test
- Sample market data clearly labelled as demo data
- A GitHub Actions workflow that builds a debug APK

## Important
This starter does **not** yet include live exchange prices, X feeds, news APIs, blockchain security scanning, AI trading signals, wallet intelligence, or background market alerts. Those need data-provider accounts, a backend, API keys stored securely on the backend, and testing. It does not promise 90% accuracy.

## Build an APK
1. Upload this project folder to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Run the workflow named **Build KOBRA Android APK** (or push to the main branch).
4. Open the completed workflow run and download the `kobra-debug-apk` artifact.
5. Extract `app-debug.apk` and install it on your Android phone. Android may ask you to allow installs from that source.

For local development, open the folder in Android Studio and run the app. Android SDK 35 and JDK 17 are required.
