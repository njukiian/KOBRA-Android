package com.kobra.crypto

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 13, 18)
    private val panel = Color.rgb(17, 24, 33)
    private val line = Color.rgb(39, 52, 65)
    private val green = Color.rgb(72, 224, 160)
    private val muted = Color.rgb(142, 160, 179)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        createNotificationChannel()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun baseColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(16), dp(12), dp(16), dp(20))
    }

    private fun text(value: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundColor(panel)
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = dp(10)
        layoutParams = p
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.rgb(5, 20, 14))
            setBackgroundColor(green)
            setOnClickListener { action() }
        }

    private fun shell(title: String, subtitle: String): LinearLayout {
        val root = baseColumn()
        root.addView(text("🐍  KOBRA", 22f, green, true))
        root.addView(text("CRYPTO INTELLIGENCE", 10f, muted, true))
        root.addView(text(title, 25f, Color.WHITE, true))
        root.addView(text(subtitle, 12f, muted))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content)
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        listOf("Home", "Markets", "Safety", "News", "Alerts").forEach { item ->
            val b = TextView(this).apply {
                text = item
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(if (item == title) green else muted)
                setPadding(dp(5), dp(10), dp(5), dp(10))
                setOnClickListener { navigate(item) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
        return root
    }

    private fun navigate(page: String) {
        when (page) {
            "Markets" -> showMarkets()
            "Safety" -> showSafety()
            "News" -> showNews()
            "Alerts" -> showAlerts()
            else -> showHome()
        }
    }

    private fun showHome() {
        shell("Home", "See the move. Detect the risk. Strike smart.")
        val stats = card()
        stats.addView(text("MARKET SNAPSHOT", 11f, muted, true))
        stats.addView(text("Meme sector watchlist", 18f, Color.WHITE, true))
        stats.addView(text("Prices and signals shown here are sample data until live feeds are connected.", 12f, muted))
        content.addView(stats)

        val signal = card()
        signal.addView(text("AI SIGNAL DESK", 11f, green, true))
        signal.addView(text("BONK   •   WAIT", 17f, Color.WHITE, true))
        signal.addView(text("Example only: wait for confirmation. No live recommendation is being generated.", 12f, muted))
        content.addView(signal)

        val risk = card()
        risk.addView(text("SAFETY FIRST", 16f, Color.WHITE, true))
        risk.addView(text("KOBRA is a research assistant, not a profit guarantee. Verify contracts and liquidity before trading.", 12f, muted))
        content.addView(risk)
    }

    private fun showMarkets() {
        shell("Markets", "Meme coin watchlist · demo quotes")
        val rows = listOf(
            "DOGE  |  $0.1642  |  +4.8%  |  Binance / OKX",
            "BONK  |  $0.0000218  |  +9.2%  |  OKX / Bybit",
            "WIF   |  $1.42  |  -2.1%  |  Binance / Kraken",
            "PEPE  |  $0.0000097  |  +6.4%  |  Binance / Coinbase",
            "BRETT |  $0.071  |  -1.6%  |  DEX venues"
        )
        rows.forEach { row ->
            val c = card()
            c.addView(text(row, 14f, Color.WHITE, true))
            c.addView(text("Illustrative quote — not a live executable price.", 11f, muted))
            content.addView(c)
        }
    }

    private fun showSafety() {
        shell("Safety", "Token contract risk-check preview")
        val c = card()
        c.addView(text("PASTE TOKEN CONTRACT", 11f, green, true))
        val input = EditText(this).apply {
            hint = "Contract address"
            setHintTextColor(muted)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setBackgroundColor(Color.rgb(10, 17, 24))
        }
        c.addView(input)
        c.addView(actionButton("Analyse token") {
            val address = input.text.toString().trim()
            val msg = if (address.isBlank()) "Enter a contract address first." else
                "UNVERIFIED: this prototype has not queried a blockchain. A real scan must check honeypot behaviour, owner permissions, liquidity locks, holder concentration and deployer history."
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        })
        c.addView(text("A real security result needs a connected chain scanner. A score is never proof that a token is safe.", 12f, muted))
        content.addView(c)
    }

    private fun showNews() {
        shell("News", "Crypto headlines · feed categories")
        listOf(
            "Bitcoin & macro events" to "CPI, FOMC, ETF flows and major market events.",
            "Solana ecosystem" to "Network status, DEX activity and token launches.",
            "Regulation & exchanges" to "Official exchange notices and regulator statements.",
            "Meme coin market" to "Verified project updates and social momentum."
        ).forEach { (title, desc) ->
            val c = card()
            c.addView(text(title, 16f, Color.WHITE, true))
            c.addView(text(desc, 12f, muted))
            content.addView(c)
        }
        content.addView(text("No live news provider is connected in this build.", 11f, muted))
    }

    private fun showAlerts() {
        shell("Alerts", "Important market events")
        val c = card()
        c.addView(text("PUSH NOTIFICATIONS", 16f, Color.WHITE, true))
        c.addView(text("Enable Android notifications and send a local test alert.", 12f, muted))
        c.addView(actionButton("Enable notifications") { requestNotificationPermission() })
        c.addView(actionButton("Send test alert") { sendTestNotification() })
        content.addView(c)
        listOf("Whale movement watch", "Liquidity risk threshold", "Breaking news monitor").forEach {
            val a = card()
            a.addView(text(it, 14f, Color.WHITE, true))
            a.addView(text("Alert rule placeholder — live monitoring is not connected yet.", 11f, muted))
            content.addView(a)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("kobra_alerts", "KOBRA alerts", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        } else sendTestNotification()
    }

    private fun sendTestNotification() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Allow notifications first.", Toast.LENGTH_SHORT).show()
            return
        }
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = android.app.Notification.Builder(this, "kobra_alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("KOBRA test alert")
            .setContentText("This is a local demo notification, not a live market alert.")
            .setAutoCancel(true)
            .build()
        manager.notify(1001, notification)
    }
}
